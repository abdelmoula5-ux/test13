import {useEffect,useState} from "react"
import axios from "axios"
import QuizCard from "../components/QuizCard"

export default function Quiz(){

  const [quizzes,setQuizzes]=useState([])

  useEffect(()=>{
    axios.get("http://localhost:5000/api/quiz/all")
    .then(res=>setQuizzes(res.data))
  },[])

  return(
    <div>
      <h1>Quiz Platform</h1>
      {quizzes.map(q=>(
        <QuizCard key={q._id} quiz={q}/>
      ))}
    </div>
  )
}