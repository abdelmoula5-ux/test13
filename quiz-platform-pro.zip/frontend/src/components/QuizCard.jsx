import axios from "axios"

export default function QuizCard({quiz}){

  const vote=async(index)=>{
    await axios.post(`http://localhost:5000/api/quiz/vote/${quiz._id}`,{
      optionIndex:index
    })
    alert("Vote submitted")
  }

  return(
    <div style={{border:"1px solid #ccc",padding:20,margin:20}}>
      <h3>{quiz.question}</h3>

      {quiz.options.map((o,i)=>(
        <button key={i} onClick={()=>vote(i)}>
          {o.text}
        </button>
      ))}
    </div>
  )
}