const router=require("express").Router()
const Quiz=require("../models/Quiz")

router.post("/create",async(req,res)=>{
  const quiz=new Quiz(req.body)
  await quiz.save()
  res.json(quiz)
})

router.get("/all",async(req,res)=>{
  const quizzes=await Quiz.find()
  res.json(quizzes)
})

router.post("/vote/:id",async(req,res)=>{
  const {optionIndex}=req.body
  const quiz=await Quiz.findById(req.params.id)
  quiz.options[optionIndex].votes++
  await quiz.save()
  res.json(quiz)
})

module.exports=router